package mygame;



import com.jme3.bounding.BoundingBox;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.control.CharacterControl;
import com.jme3.scene.Spatial;

/**
 *
 * @author user
 */
public class Kaktus extends Rintangan
{
    public Kaktus(Spatial kaktus)
    {
        super(kaktus);
    }
}
