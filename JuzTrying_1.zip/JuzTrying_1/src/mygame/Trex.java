package mygame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import com.jme3.animation.AnimChannel;
import com.jme3.animation.AnimControl;
import com.jme3.animation.AnimEventListener;
import com.jme3.bounding.BoundingBox;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.control.CharacterControl;
import com.jme3.input.KeyInput;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;

/**
 *
 * @author user
 */
public class Trex implements AnimEventListener{
    
    private final CharacterControl trexControl;
    private final Node trexPlayer;
    private AnimChannel channel;
    private AnimControl animControl;
    
    public Trex(Spatial trex){
        trexPlayer=(Node) trex;
        trexPlayer.setLocalScale(0.1f);
        trexPlayer.setLocalTranslation(0.000475f, 0, 120);
        BoundingBox boundingBox =(BoundingBox) trexPlayer.getWorldBound();
        float radius=boundingBox.getXExtent();
        float height=boundingBox.getYExtent();
        
        CapsuleCollisionShape playerShape=new CapsuleCollisionShape(radius,height);
        
        trexControl=new CharacterControl(playerShape,1.0f);
        trexPlayer.addControl(trexControl);
        trexControl.setJumpSpeed(15);
        
        animControl=trexPlayer.getChild("Cube").getControl(AnimControl.class);
        animControl.addListener(this);
        channel=animControl.createChannel();
    }

    public AnimChannel getChannel(){
        return this.channel;
    }
    
    public CharacterControl getTrexControl() {
        return trexControl;
    }

    public Spatial getTrexPlayer() {
        return trexPlayer;
    }

    @Override
    public void onAnimCycleDone(AnimControl control, AnimChannel channel, String animName) {
        
    }

    @Override
    public void onAnimChange(AnimControl control, AnimChannel channel, String animName) {
        
    }
    
}
